self.__precacheManifest = [
  {
    "revision": "bb4fd708676738d66cc4",
    "url": "/static/css/main.e7ffe835.chunk.css"
  },
  {
    "revision": "bb4fd708676738d66cc4",
    "url": "/static/js/main.bb4fd708.chunk.js"
  },
  {
    "revision": "b0e29ea1530cd5de8cf4",
    "url": "/static/css/1.71ac2ffc.chunk.css"
  },
  {
    "revision": "b0e29ea1530cd5de8cf4",
    "url": "/static/js/1.b0e29ea1.chunk.js"
  },
  {
    "revision": "229c360febb4351a89df",
    "url": "/static/js/runtime~main.229c360f.js"
  },
  {
    "revision": "a5cd38c88a04b50447e0021b7d1ff50a",
    "url": "/static/media/refresh.a5cd38c8.jpg"
  },
  {
    "revision": "bc67aa640828651c51b5885ba1353c36",
    "url": "/index.html"
  }
];